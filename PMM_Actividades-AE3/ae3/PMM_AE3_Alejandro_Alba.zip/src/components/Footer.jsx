import React from 'react'

export default function Footer() {
    return (
        <div>
            <p>Autor: Alejandro Alba Carretón</p>
        </div>
    )
}
